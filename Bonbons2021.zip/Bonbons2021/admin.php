<?php
include "header.php" ;
?>

<div class="container">
<div class="row">
<div class="col-md-5">
<form method="POST" action='verif.php'>
  <div class="form-group">
    <label>Identifiant</label>
    <input type="text" class="form-control" name="login"  placeholder="Identifiant">
    </div>

  <div class="form-group">
    <label>Mot de passe</label>
    <input type="password" class="form-control" name="mdp" placeholder="Mot de passe">
  </div>

  <button type="submit" class="btn btn-primary mt-3">Submit</button>
</form>
</div>
</div>
</div>